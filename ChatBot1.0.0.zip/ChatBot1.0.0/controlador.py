import os
from sqlalchemy import create_engine
from langchain.chat_models.openai import ChatOpenAI

from langchain.sql_database import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
#import spacy
#from spacy.lang.es import Spanish
import a_env_vars 


# Configurar la conexión a la base de datos
db_connection_string = "mssql+pyodbc://botchattest:exbotchattest@10.20.30.47/Cafeteria?driver=SQL Server Native Client 11.0"
db_uri = "mssql+pyodbc://botchattest:exbotchattest@10.20.30.47/Cafeteria?driver=SQL Server Native Client 11.0"

# Configurar la API DE CHATOPENAI
os.environ["OPENAI_API_KEY"] = a_env_vars.OPENAI_API_KEY
model_name = "gpt-3.5-turbo-16k"

# Definir un mapeo de nombres de columnas a alias
column_alias_mapping = {
}

# Probar conexión a la base de datos
try:
    engine = create_engine(db_connection_string)
    connection = engine.connect()
    print("Conexión exitosa a la base de datos.")
    connection.close()
except Exception as e:
    print(f"Error al conectar a la base de datos: {e}")

# Crear el modelo chatopenai
openai = ChatOpenAI(model_name=model_name, temperature=0)

# Crear la cadena de SQLDatabaseChain
template = """you are a chatbot having a conversation with a human.
{chat_history} human: {human_input} chatbot: """

prompt = PromptTemplate(
    input_variables=["chat_history", "human_input"], template=template
)
memory = ConversationBufferMemory(memory_key="chat_history", K=100, return_messages=True)

db = SQLDatabase.from_uri(db_uri)
db_chain = SQLDatabaseChain.from_llm(openai, db, memory=memory, verbose=True, top_k=100)

# Formato personalizado de respuestas

#Formato temporal para el mapeo de los metaDatos
def formato_consulta(question): 
    return f"""
    **Siempre**
    Dada una pregunta del usuario:
    1. Tomar datos de las tabla dbo.tblOrdenes, OrdenCombo, OrdenComboDetalle, Empleados, tblEmpresa, Departamentos y ComboArticulos
    2. Relaciona la columna empleado de la tabla tblOrdenes con la columna id de la tabla Empleados
    3. Relaciona la columna Empresa de la tabla tblOrdenes con la columna id de la tabla tblEmpresa
    4. Relaciona la columna Departamento de la tabla tblOrdenes con la columna DepartamentoID de la tabla Departamentos
    5. Relaciona la columna ArticuloID de la tabla OrdenComboDetalle con la columna ArticuloID de la tabla ComboArticulos
    6. Relaciona la columna ComboOrderID de la tabla OrdenComboDetalle con la columna ComboOrderID de la tabla OrdenComboDetalle
    7. Relaciona la columna OrdenID de la tabla OrdenCombo con la columna Orden de la tabla tblOrdenes
    8. Relaciona la columna ComboID de la tabla OrdenCombo con la columna CoboArtID de la tabla ComboArticulos
    9. No tomar en cuenta los CombosArticulos con el CoboArtID 350 y 356
    9. Leer los datos de la BD con las tablas mencionadas, hacer la consulta correspondiente en SQL y devolver los resultados en español
    Pregunta del usuario: "{question}"
    """
def mapear_alias_a_columna(query):
    # Tokeniza la consulta para separar las palabras
    tokens = query.split()

    # Inicializa una lista para almacenar las palabras mapeadas
    palabras_mapeadas = []

    # Itera a través de las palabras de la consulta
    for token in tokens:
        for columna, alias in column_alias_mapping.items():
            if token.lower() in alias:
                palabras_mapeadas.append(columna)

    # Reemplaza las palabras mapeadas en la consulta original
    for palabra_original, palabra_mapeada in zip(tokens, palabras_mapeadas):
        query = query.replace(palabra_original, palabra_mapeada, 1)

    return query


# Función para hacer la consulta
def consulta(input_usuario):
    try:
        mensaje_formateado = formato_consulta(input_usuario)

        # Mapear alias a nombres de columnas
        column_identity_mapping = mapear_alias_a_columna(input_usuario)
        for col in column_identity_mapping:
            mensaje_formateado = mensaje_formateado.replace(f"[{col}]", f"'{col}'")

        resultado = db_chain.run(mensaje_formateado)
        return resultado
    except Exception as e:
        # En caso de excepción, muestra un mensaje amigable al usuario
        mensaje_error = "Lo siento, ha ocurrido un error al procesar tu consulta. Por favor, inténtalo de nuevo."
        print(f"Error: {e}")  # Muestra el error real en la consola
        return mensaje_error

