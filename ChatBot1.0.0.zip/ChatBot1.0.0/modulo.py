import openai
import streamlit as st
import controlador

with st.sidebar:
    st.caption("🍔 El futuro de la comida y la inteligencia articial 🍔")
    "[descubre más sobre PapaOtto](https://www.papaotto.com/)"
    
st.title("Version 0.1.0 de Machine Learning PapaOtto")
st.caption("🚀 Escribe tus consultas de sobre Data Science (Porfavor, sé preceiso con las dudas que tengas) impulsado por OpenAi LLM")
if "message" not in st.session_state:
    st.session_state["message"] = [{"role": "assistant", "content": "¿En que te puedo ayudar?"}]

if "pregunta" not in st.session_state:
    st.session_state.pregunta = []
if "respuesta" not in st.session_state:
    st.session_state.respuesta = []

for msg in st.session_state.message:
    st.chat_message(msg["role"]).write(msg["content"])
    
    
def click():
    if st.session_state.user:
        pregunta = st.session_state.user
        respuesta = controlador.consulta(pregunta)
        
        st.session_state.pregunta.append(pregunta)
        st.session_state.respuesta.append(respuesta)
        st.session_state.message.append({"role": "user", "content": pregunta})
        st.session_state.message.append({"role": "assistant", "content": pregunta})
        
        # muestra el Historial de conversación actualizado
        
# Limpiar los campos

st.session_state.user = ''

with st.form('my-form'):
    query = st.text_input('¿En que puedo ayudarte?:', key='user', help='Pulsa Enviar para hacer la pregunta')
    submit_button = st.form_submit_button('Enviar', on_click=click)
    
st.write("Chatbot desarrollado En Papa Otto")